class cal{
    add(a,b){
        return a+b;
    }
    multip(a,b){
        return a*b;
    }
}
module.exports = cal;
exports.divde=(a,b)=>a/b;